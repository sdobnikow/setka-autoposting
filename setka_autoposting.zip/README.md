# Автопостинг Telegram @setkahhegor

300 постов из исходного Word-документа, порядок сохранён. **10 постов в день, каждый час с 07:00 до 16:00 по Москве.** После публикации счётчик увеличивается, посты не повторяются.

## Настройка
1. Загрузить файлы в корень репозитория, а файл `telegram.yml` в `.github/workflows/telegram.yml`.
2. GitHub → Settings → Secrets and variables → Actions → New repository secret. Имя: `TELEGRAM_BOT_TOKEN`, значение: токен от BotFather. Никому не отправлять и в файлы не записывать.
3. GitHub → Settings → Actions → General → Workflow permissions → Read and write permissions → Save.
4. GitHub → Actions → Telegram posts — 10 per day → Enable workflow (если требуется).

Проверка: после сохранения токена можно запустить workflow вручную через `Run workflow` (это отправит **следующий** пост сразу, если в Москве между 07:00 и 16:59). Запуск по cron в GitHub Actions иногда задерживается.

**Важно:** при замене `posts.json` счётчик `sent_count.txt` не сбрасывается автоматически. Для новой очереди нужно отдельно сбросить счётчик до 0, иначе будут пропуски.

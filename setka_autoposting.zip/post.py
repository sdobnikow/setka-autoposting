import json, os, pathlib, urllib.parse, urllib.request, subprocess
from datetime import datetime
from zoneinfo import ZoneInfo

ROOT = pathlib.Path(__file__).resolve().parent

def main():
    now = datetime.now(ZoneInfo("Europe/Moscow"))
    if not (7 <= now.hour <= 16):
        print("Outside Moscow posting window")
        return
    token = os.environ["TELEGRAM_BOT_TOKEN"]
    posts = json.loads((ROOT / "posts.json").read_text(encoding="utf-8"))
    counter = ROOT / "sent_count.txt"
    sent = int(counter.read_text().strip())
    if sent >= len(posts):
        print("All posts published")
        return
    message = posts[sent]
    if len(message) > 4096:
        raise ValueError("Post too long for Telegram")
    data = urllib.parse.urlencode({"chat_id": "@setkahhegor", "text": message}).encode()
    request = urllib.request.Request("https://api.telegram.org/bot" + token + "/sendMessage", data=data)
    with urllib.request.urlopen(request, timeout=30) as response:
        result = json.loads(response.read())
    if not result.get("ok"):
        raise RuntimeError("Telegram did not confirm publication")
    counter.write_text(str(sent + 1) + "\n")
    subprocess.run(["git", "config", "user.name", "github-actions[bot]"], check=True)
    subprocess.run(["git", "config", "user.email", "41898282+github-actions[bot]@users.noreply.github.com"], check=True)
    subprocess.run(["git", "add", "sent_count.txt"], check=True)
    subprocess.run(["git", "commit", "-m", "Record published post " + str(sent + 1)], check=True)
    subprocess.run(["git", "push"], check=True)
    print("Published post", sent + 1, "of", len(posts))

if __name__ == "__main__":
    main()
